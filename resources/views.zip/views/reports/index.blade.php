@extends('layouts.app')



@section('content')
<div class="container p-4 shadow-lg bg-white rounded">
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Reports</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('reports.create') }}"> Novo Report</a>
            </div>
        </div>
    </div>



    <table class="table table-bordered">
        <tr>
            <th>Nª</th>
            <th>Endereço</th>
            <th>Problemas</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($reports as $report)
        <tr>
            <td>{{ $report->id }}</td>

            <td>{{ $report->rua }},{{ $report->numero }},{{ $report->complemento }},{{ $report->bairro }},{{ $report->cidade }},{{ $report->estado }}</td>
            <td class="text-nowrap w-25">
                <?php
                if (isset($report->drenagem_urbana)&&$report->drenagem_urbana){echo "Sem drenagem urbana,";}
                if (isset($report->agua_potavel)&&$report->agua_potavel){echo "Sem água potavel,";}
                if (isset($report->coleta_tratamento_esgoto)&&$report->coleta_tratamento_esgoto){echo "Sem coleta e/ou tratamento de esgoto,";}
                if (isset($report->coleta_residuos_solidos)&&$report->coleta_residuos_solidos){echo "Sem Coleta de residuos solidos,";}

                ?>
            </td>
            <td>
                <form action="{{ route('reports.destroy',$report->id) }}" method="POST">



                    <a class="btn btn-primary" href="{{ route('reports.edit',$report->id) }}">Edit</a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

</div>
@endsection
